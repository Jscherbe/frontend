# About Components

- Won't always offer the ability to rename styles 
- Components are reusable elements 
- They contain styles (unlike libraries)